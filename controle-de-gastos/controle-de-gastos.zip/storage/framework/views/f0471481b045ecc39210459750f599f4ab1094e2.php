<div id="<?php echo e($idModal); ?>" class="modal " tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title <?php echo e($corTitulo); ?>"><strong><?php echo e($tituloModal); ?></strong></h4>
            </div>
            <form action="<?php echo e($linkRequisicao); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Valor</span>
                                </div>
                                <input type="number" min="0" class="form-control" name="valor" value="<?php echo e(isset($valor) ? $valor : ''); ?>" id="valor">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Categoria</span>
                                </div>
                                <select class="form-control" name="categoria" id="categoria">
                                    <option selected><?php echo e(isset($categoria) ? $categoria : 'Selecione uma categoria...'); ?></option>
                                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option><?php echo e($categoria->categoria); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-12 mt-3">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Descrição</span>
                                </div>
                                <input type="text" class="form-control" id="descricao" name="descricao" value="<?php echo e(isset($descricao) ? $descricao : ''); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal" name="button">Fechar</button>
                    <button type="submit" class="btn btn-primary" name="button">Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\mayki\Documents\GitHub\Controle-de-Gastos-Laravel\controle-de-gastos\resources\views/layouts/modal.blade.php ENDPATH**/ ?>