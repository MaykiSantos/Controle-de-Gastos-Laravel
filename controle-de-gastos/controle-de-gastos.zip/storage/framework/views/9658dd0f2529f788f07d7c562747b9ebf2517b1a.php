<div class="mx-3 my-3">
<a href="<?php echo e($link); ?>" class="btn btn-primary">
    <h5 class="card-title display-1"><?php echo e($ano); ?></h5>
</a>
</div>
<?php /**PATH C:\Users\mayki\Documents\GitHub\Controle-de-Gastos-Laravel\controle-de-gastos\resources\views/layouts/botao-grande.blade.php ENDPATH**/ ?>
