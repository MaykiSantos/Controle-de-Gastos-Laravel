<?php $__env->startSection('conteudo-lateral'); ?>
    <div class="container">
        <div class="row">


            <div id="receita" class="col-12 border rounded shadow bg-white mt-4">
                <div class="row mt-4">
                    <h1 id="mes-ano"><?php echo e($mesDescricao->get($mes)); ?>/<?php echo e($ano); ?></h1>
                </div>
                <div class="text-center my-4">
                    <button class="btn btn-lg btn-success ml-3" type="button" name="button" data-toggle="modal" data-target="#modalReceita">
                        Adicionar Receita
                    </button>
                    <?php echo $__env->make('layouts.modal',['idModal'=>'modalReceita',
                                'tituloModal'=> 'Receita',
                                'corTitulo'=>'text-success',
                                'categorias'=> $receitaCategorias,
                                'linkRequisicao'=> "/controle-de-gastos/{$ano}/{$mes}/salvar-receita"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <button class="btn btn-lg btn-danger ml-3" type="button" name="button" data-toggle="modal" data-target="#modalDespesa">
                        Adicionar Despesa
                    </button>
                    <?php echo $__env->make('layouts.modal', ['idModal'=>'modalDespesa',
                                'tituloModal'=>'Despesa',
                                'corTitulo'=>'text-danger',
                                'categorias'=> $despesaCategorias,
                                'linkRequisicao'=> "/controle-de-gastos/{$ano}/{$mes}/salvar-despesa"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <button class="btn btn-lg btn-primary ml-3" type="button" name="button" data-toggle="modal" data-target="#modalReserva">
                        Adicionar Reserva
                    </button>
                    <?php echo $__env->make('layouts.modal', ['idModal'=>'modalReserva',
                                'tituloModal'=>'Reserva',
                                'corTitulo'=>'text-primary',
                                'categorias'=> $reservaCategorias,
                                'linkRequisicao'=> "/controle-de-gastos/{$ano}/{$mes}/salvar-reserva"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

            <div id="receita" class="col-12 border rounded shadow bg-white mt-4 py-2">
                <h2 class="text-success"><strong>Receitas</strong></h2>
                <table class="table table-bordered">
                    <thead class="thead-light">
                    <th>Categoria</th>
                    <th>Descrição</th>
                    <th>Valor</th>
                    <th></th>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $receitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($receita->categoria); ?></td>
                            <td><?php echo e($receita->descricao); ?></td>
                            <td>R$ <?php echo e($receita->valor); ?></td>
                            <td class="text-right d-flex justify-content-end">
                                <button class="btn btn-outline-secondary btn-sm" data-toggle="modal" data-target="#modalEditarReceita<?php echo e($receita->id); ?>">
                                    <i class="far fa-edit"></i>
                                    Editar
                                </button>

                                <?php echo $__env->make('layouts.modal', ['idModal'=>"modalEditarReceita{$receita->id}",
                                'tituloModal'=>'Editar Receita',
                                'corTitulo'=>'text-success',
                                'categorias'=> $receitaCategorias,
                                'categoria'=> "$receita->categoria",
                                'valor'=>"$receita->valor",
                                'descricao'=> "$receita->descricao",
                                'linkRequisicao'=> "/controle-de-gastos/{$ano}/{$mes}/editar-receita/{$receita->id}"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <form action="/controle-de-gastos/<?php echo e($ano); ?>/<?php echo e($mes); ?>/apagar-receita/<?php echo e($receita->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-outline-danger btn-sm" >
                                        <i class="far fa-trash-alt"></i>
                                        Excluir
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <div id="receita" class="col-12 border rounded shadow bg-white mt-4 py-2">
                <h2 class="text-danger"><strong>Despesas</strong></h2>
                <table class="table table-bordered">
                    <thead class="thead-light">
                    <th>Categoria</th>
                    <th>Descrição</th>
                    <th>Valor</th>
                    <th></th>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $despesas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $despesa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td><?php echo e($despesa->categoria); ?></td>
                            <td><?php echo e($despesa->descricao); ?></td>
                            <td>R$ <?php echo e($despesa->valor); ?></td>
                            <td class="text-right d-flex justify-content-end">
                                <button class="btn btn-outline-secondary btn-sm" data-toggle="modal" data-target="#modalEditarDespesa<?php echo e($despesa->id); ?>">
                                    <i class="far fa-edit"></i>
                                    Editar
                                </button>

                                <?php echo $__env->make('layouts.modal', ['idModal'=>"modalEditarDespesa{$despesa->id}",
                                'tituloModal'=>'Editar Despesa',
                                'corTitulo'=>'text-danger',
                                'categorias'=> $despesaCategorias,
                                'categoria'=> "$despesa->categoria",
                                'valor'=>"$despesa->valor",
                                'descricao'=> "$despesa->descricao",
                                'linkRequisicao'=> "/controle-de-gastos/{$ano}/{$mes}/editar-despesa/{$despesa->id}"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <form action="/controle-de-gastos/<?php echo e($ano); ?>/<?php echo e($mes); ?>/apagar-despesa/<?php echo e($despesa->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-outline-danger btn-sm" >
                                        <i class="far fa-trash-alt"></i>
                                        Excluir
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <div id="receita" class="col-12 border rounded shadow bg-white mt-4 mb-4 py-2">
                <h2 class="text-primary"><strong>Reservas</strong></h2>
                <table class="table table-bordered">
                    <thead class="thead-light">
                    <th>Categoria</th>
                    <th>Descrição</th>
                    <th>Valor</th>
                    <th></th>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($reserva->categoria); ?></td>
                            <td><?php echo e($reserva->descricao); ?></td>
                            <td>R$ <?php echo e($reserva->valor); ?></td>
                            <td class="text-right d-flex justify-content-end">
                                <button class="btn btn-outline-secondary btn-sm" data-toggle="modal" data-target="#modalEditarReserva<?php echo e($reserva->id); ?>">
                                    <i class="far fa-edit"></i>
                                    Editar
                                </button>

                                <?php echo $__env->make('layouts.modal', ['idModal'=>"modalEditarReserva{$reserva->id}",
                                'tituloModal'=>'Editar Reserva',
                                'corTitulo'=>'text-danger',
                                'categorias'=> $reservaCategorias,
                                'categoria'=> "$reserva->categoria",
                                'valor'=>"$reserva->valor",
                                'descricao'=> "$reserva->descricao",
                                'linkRequisicao'=> "/controle-de-gastos/{$ano}/{$mes}/editar-reserva/{$reserva->id}"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <form action="/controle-de-gastos/<?php echo e($ano); ?>/<?php echo e($mes); ?>/apagar-reserva/<?php echo e($reserva->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-outline-danger btn-sm" >
                                        <i class="far fa-trash-alt"></i>
                                        Excluir
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mayki\Documents\GitHub\Controle-de-Gastos-Laravel\controle-de-gastos\resources\views/detalhes-mes.blade.php ENDPATH**/ ?>