<?php $__env->startSection('conteudo-lateral'); ?>
    <div class="container">
        <?php echo csrf_field(); ?>

        <div class="row" id="icones-topo">
            <div class="col div-icone-topo">
                <p class="titulo position-absolute">Saldo Atual</p>
                <div class="valor position-absolute"><strong>R$</strong> <?php echo e($totalSaldo); ?></div>
                <img class="img-fluid" src="<?php echo e(asset('img\icone-caixa-entrada.svg')); ?>" alt="">
            </div>

            <div class="col div-icone-topo">
                <p class="titulo position-absolute">Receitas</p>
                <div class="valor position-absolute"><strong>R$</strong> <?php echo e($totalReceitas); ?></div>
                <img class="img-fluid" src="<?php echo e(asset('img\icone-grafico-mais.svg')); ?>" alt="">
            </div>

            <div class="col div-icone-topo">
                <p class="titulo position-absolute">Despesas</p>
                <div class="valor position-absolute"><strong>R$</strong> <?php echo e($totalDespesas); ?></div>
                <img class="img-fluid" src="<?php echo e(asset('img\icone-grafico-menos.svg')); ?>" alt="">

            </div>

            <div class="col div-icone-topo">
                <p class="titulo position-absolute">Reservas</p>
                <div class="valor position-absolute"><strong>R$</strong> <?php echo e($totalReservas); ?></div>
                <img class="img-fluid" src="<?php echo e(asset('img\icone-caixa-reserva.svg')); ?>" alt="">
            </div>

        </div>


        <div id="" class="row mt-4"><!--Graficos detalhados-->
            <div class="col"><!--Graficos coluna esquerda-->
                <div id="grafico-despesas-mes" class="border rounded shadow bg-white" style="width: 100%; height: 100%;"><!--Grafico despesas do mes--></div>
            </div><!--Fim graficos coluna esquerda-->
            <div class="col"><!--Graficos coluna direita-->
                <div id="grafico-receita-mes" class="border rounded shadow bg-white"><!--Grafico receita do mes--></div>

            </div><!--Fim graficos coluna direita-->
        </div><!--Fim graficos detalhados-->
    </div>
    <div class="container mt-4">

        <div class="row">
            <div class="col">
                <div id="receitas-despesas-6-meses" class="border rounded shadow bg-white">
                    Receitas x Despesas nos últimos 6 meses:<br>
                    grafico em barra comparando os dois valores
                </div>
            </div>
            <div class="col">
                <div id="receita-despesas-mes"class="border rounded shadow bg-white">

                </div>
            </div>
            <div class="col-12">
                <div id="grafico-geral" class="border rounded shadow bg-white mt-4 mb-4">

                </div>
            </div>
        </div>
        <input type="hidden" name="usuario" value="<?php echo e($request->User()->id); ?>">
    </div>


    <!-- Scripts JS personalizado-->

    <script src="<?php echo e(asset('js/controller/dashboard.js')); ?>"></script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mayki\Documents\GitHub\Controle-de-Gastos-Laravel\controle-de-gastos\resources\views/dashboard.blade.php ENDPATH**/ ?>