<?php $__env->startSection('conteudo-lateral'); ?>
    <div class="input-group input-group-sm mb-3">
        <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroup-sizing-sm">Pequeno</span>
        </div>
        <input type="date" class="form-control" aria-label="Exemplo do tamanho do input" aria-describedby="inputGroup-sizing-sm">
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mayki\Documents\GitHub\Controle-de-Gastos-Laravel\controle-de-gastos\resources\views/registros.blade.php ENDPATH**/ ?>