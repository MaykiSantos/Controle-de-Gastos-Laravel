<?php $__env->startSection('content'); ?>
    <pre>
        Usuario: <?php echo e($usuario); ?>

        Despesa: <?php echo e($despesa); ?>






    </pre>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mayki\Documents\GitHub\Controle-de-Gastos-Laravel\controle-de-gastos\resources\views/teste.blade.php ENDPATH**/ ?>