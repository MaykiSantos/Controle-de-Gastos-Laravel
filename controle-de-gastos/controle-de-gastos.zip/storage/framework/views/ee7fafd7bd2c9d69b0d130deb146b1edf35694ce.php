<?php $__env->startSection('conteudo-lateral'); ?>

    <div class="container d-flex">
        <div class="row justify-content-center">



            <?php $__currentLoopData = $anos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ano): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('layouts.botao-grande', [
                        'ano'=> $ano,
                        'link'=> "/controle-de-gastos/{$ano}"
                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mayki\Documents\GitHub\Controle-de-Gastos-Laravel\controle-de-gastos\resources\views/registros-ano.blade.php ENDPATH**/ ?>