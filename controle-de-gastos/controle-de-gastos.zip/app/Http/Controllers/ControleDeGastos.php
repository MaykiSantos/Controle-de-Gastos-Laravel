<?php

namespace App\Http\Controllers;

use App\Despesa;
use App\DespesaCategoria;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ControleDeGastos extends Controller
{

}
