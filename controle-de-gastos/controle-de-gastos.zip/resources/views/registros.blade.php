@extends('layouts.principal')

@section('conteudo-lateral')
    <div class="input-group input-group-sm mb-3">
        <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroup-sizing-sm">Pequeno</span>
        </div>
        <input type="date" class="form-control" aria-label="Exemplo do tamanho do input" aria-describedby="inputGroup-sizing-sm">
    </div>

@endsection
